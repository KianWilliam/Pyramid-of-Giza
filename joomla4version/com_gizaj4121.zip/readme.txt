Giza version 1.0.0  is a free software which is developed by
KWProductions Co. It is a package including both component and module.
Module is using the site part component's model, so without it, it will not work.
The license is GNU/GPLv3
It is written for joomla 4.x,fill all formfields in 
module to make it work, and don't forget the number of images 
must be divisble by 8 and equal or greater than 8.
Regarding the pyramid and its formula I explain briefly for eager young minds,
ofcourse the ways I employed were a mixture of geometery and trigonometery, also
we used to build formula's in mechanic of soil via creating curves and using medians of different vals,
I used it here too, it has been years from those times and I am positive there are other ways to reach the same results:
consider a div in broswer with no z dimension, the angle of pyramid relative to horizon is 30, so the other is 60 deg.
create a triangle, from apex of that triangle continue to the amount of transferance and create another triangle.
Its angles are again 30 and 60. so a simple formula: sin60 = h/h+x , h is dimension we settle for pyramid and Transferance or T = x / 2.
So far it is geometery and trigonometerey. Now a little ways of mechanic of soil (I am always a geologist and geophysicist): 
to be able to settle pyramid in the same posture for quite different sizes: we need a relative constant to be added to T so that our pyramid
will remain in good form. for example
Width   Transfer
555      25
455      20
355      15
255      10
155      5
the values above are all experimental, I give the dimension and for constant value I got the best number, so now we can have a function, an experimental
function like this: 100x=5y , input the values in the function and experimentally by viewing the pyramid a close constant shall be obtained as this:
constant = (width - 55) / 20 , e.g dim = 555, to reach 100x=5y , 555-55/20 = 500/20 =x - 55 /20 = y or constant.
the same way for apex, left of dim's left of pyramid and etc.
you may view the module at:
https://www.extensions.kwproductions121.ir/mycomponents/giza-demo.html
and also downloading the complete package at:
https://www.extensions.kwproductions121.ir/mycomponents/giza-download.html
In case of any problem contact me at:
webarchitect@kwproductions121.ir
long live science.
